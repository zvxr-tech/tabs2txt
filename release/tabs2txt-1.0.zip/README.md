# tabs2txt

## Author
Mike Clark 2016 

## Description
Concatenate all of the URLs of all the tabs in a window and give the option to 
copy to clipboard.

## Compatability
Tested on:
- Mozilla/5.0 (X11; Fedora; Linux x86_64; rv:50.0) Gecko/20100101 Firefox/50.0
- Chrome Version 56.0.2924.87 (64-bit)
